
  $(function() {
    $('.flexslider').flexslider();
  });
